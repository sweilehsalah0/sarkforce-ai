import Link from "next/link";
import { Activity, Bot, ChartNoAxesCombined, Clock3, Megaphone, Settings2, Users, Wallet } from "lucide-react";
import { notFound } from "next/navigation";

const copy = {
  en: {
    workspace: "COMPANY WORKSPACE", title: "Your AI workforce.", subtitle: "A clear view of your digital employees, operations and usage.",
    overview: "OVERVIEW", employees: "AI Employees", activity: "Activity", integrations: "Integrations", billing: "Usage & Billing", settings: "Settings",
    active: "ACTIVE", team: "My Digital Employees", role: "Campaign planning, reporting and optimization",
    tasks: "Tasks completed", last: "Last activity", today: "Today", recent: "Recent activity",
    activityOne: "Workspace initialized", activityTwo: "Marketing employee template is ready to configure",
    note: "Phase 1 foundation · Demo metrics are placeholders, not live account data."
  },
  ar: {
    workspace: "مساحة عمل الشركة", title: "قوة عملك الرقمية.", subtitle: "نظرة موحدة على الموظفين الرقميين والعمليات والاستهلاك.",
    overview: "الرئيسية", employees: "الموظفون الرقميون", activity: "النشاط", integrations: "التكاملات", billing: "الاستهلاك والفوترة", settings: "الإعدادات",
    active: "نشط", team: "موظفوك الرقميون", role: "تخطيط الحملات وإعداد التقارير وتحسين الأداء",
    tasks: "المهام المكتملة", last: "آخر نشاط", today: "اليوم", recent: "النشاط الأخير",
    activityOne: "تم إعداد مساحة العمل", activityTwo: "قالب موظف التسويق جاهز للتهيئة",
    note: "المرحلة الأولى · الأرقام تجريبية وليست بيانات حساب حقيقية."
  }
} as const;

type Locale = keyof typeof copy;

export default async function DashboardPage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: rawLocale } = await params;
  if (rawLocale !== "en" && rawLocale !== "ar") notFound();
  const locale: Locale = rawLocale;
  const t = copy[locale];
  const rtl = locale === "ar";

  return (
    <div className="shell" dir={rtl ? "rtl" : "ltr"}>
      <aside className="sidebar">
        <div className="brand">SARKFORCE <span>AI</span></div>
        <div className="brand-sub">DIGITAL WORKFORCE PLATFORM</div>
        <div className="nav-label">{t.overview}</div>
        <div className="nav-item active"><ChartNoAxesCombined size={17}/>{t.overview}</div>
        <div className="nav-item"><Bot size={17}/>{t.employees}</div>
        <div className="nav-item"><Activity size={17}/>{t.activity}</div>
        <div className="nav-item"><Users size={17}/>{t.integrations}</div>
        <div className="nav-item"><Wallet size={17}/>{t.billing}</div>
        <div className="nav-item"><Settings2 size={17}/>{t.settings}</div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div>
            <div className="eyebrow">{t.workspace}</div>
            <h1>{t.title}</h1>
            <div className="subtitle">{t.subtitle}</div>
          </div>
          <div className="lang-switch">
            <Link className={locale === "en" ? "selected" : ""} href="/en">EN</Link>
            <Link className={locale === "ar" ? "selected" : ""} href="/ar">AR</Link>
          </div>
        </div>

        <div className="pill"><span className="dot"/>{t.active}</div>

        <section className="metrics">
          <div className="card"><div className="metric-label">{t.employees}</div><div className="metric-value">01</div><div className="metric-foot">1 {t.active.toLowerCase()}</div></div>
          <div className="card"><div className="metric-label">{t.tasks}</div><div className="metric-value">—</div><div className="metric-foot">Awaiting database connection</div></div>
          <div className="card"><div className="metric-label">{t.last}</div><div className="metric-value">24/7</div><div className="metric-foot">Designed for continuous operation</div></div>
          <div className="card"><div className="metric-label">{t.billing}</div><div className="metric-value">—</div><div className="metric-foot">Usage tracking not connected</div></div>
        </section>

        <div className="section-head"><h2>{t.team}</h2></div>
        <section className="card">
          <div className="employee-row">
            <div className="employee">
              <div className="employee-icon"><Megaphone size={22}/></div>
              <div><div className="employee-title">AI Media Buyer</div><div className="employee-desc">{t.role}</div></div>
            </div>
            <div className="status">{t.active}</div>
          </div>
        </section>

        <div className="section-head"><h2>{t.recent}</h2></div>
        <section className="card activity">
          <div className="activity-row"><Activity size={17}/><div>{t.activityOne}<small>System · {t.today}</small></div></div>
          <div className="activity-row"><Clock3 size={17}/><div>{t.activityTwo}<small>AI Workforce · {t.today}</small></div></div>
        </section>
        <p className="metric-foot" style={{marginTop:18}}>{t.note}</p>
      </main>
    </div>
  );
}
