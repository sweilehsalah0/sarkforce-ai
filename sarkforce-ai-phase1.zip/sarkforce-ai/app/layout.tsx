import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SARKFORCE AI — Digital Workforce",
  description: "AI employees for modern businesses."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
