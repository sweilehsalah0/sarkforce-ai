# SARKFORCE AI — Architecture Notes

## Phase 1 decisions

- One Supabase project dedicated to this product.
- One organization boundary (`organization_id`) on every tenant-owned row.
- RLS is mandatory for every exposed `public` table.
- Provider OAuth credentials are never stored as plaintext in Postgres. `token_secret_ref` points to a server-side encrypted secret store.
- All advertising writes run through a server-side policy engine.
- External side effects must be idempotent and verified after execution.

## Advertising providers

- Meta Marketing API
- Google Ads API
- TikTok Business API

Each provider adapter should implement a shared interface:
`connect`, `listAccounts`, `listCampaigns`, `createCampaign`, `updateCampaign`, `getInsights`, `pauseCampaign`.

## Agent runtime (later phase)

Queue-backed execution with durable run/task state:
queued -> running -> succeeded | failed | blocked | cancelled.

Never rely on LLM conversation memory as the source of truth for task state.
