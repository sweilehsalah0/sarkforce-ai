# Setup checklist

- [ ] Create a dedicated Supabase project named `SARKFORCE-AI` in the approved organization.
- [ ] Use `eu-west-3` (Paris) unless the organization selects a different region for compliance/latency.
- [ ] Apply the initial migration to the new project only.
- [ ] Configure Auth redirect URLs for local, preview and production domains.
- [ ] Copy Supabase URL and publishable key into `.env.local`.
- [ ] Keep secret keys server-only.
- [ ] Create GitHub repository `sarkforce-ai` and push this folder.
- [ ] Import the repository into Vercel.
- [ ] Add environment variables in Vercel for Preview and Production.
- [ ] Run `npm run typecheck`, `npm run lint`, `npm run build`.
- [ ] Test tenant isolation with two separate test users and two organizations.
